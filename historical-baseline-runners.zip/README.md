# Historical comparator source records

These are the original CarcPNU-side runners for the seven-model benchmark comparison. They retain their historical relative layout and environment/configuration records. They require the upstream OS-Carcinogenicity sources and, for CarcGC/MolBERT, separately obtained third-party repositories and pretrained assets identified in source_inventory.json and molbert_checkpoint_provenance.json. These third-party dependencies are not relicensed here.

Current comparison curves and metrics can be regenerated directly from the saved predictions through scripts/build_release_figures.py in the main code repository. The main release entry points cover CarcPNU training and inference; these historical runners are source records rather than a single-command clean installation of all comparator environments.
