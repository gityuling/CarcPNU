"""Original CarcGC architecture and organ settings on Keras 3 torch CUDA backend."""
import os
os.environ['KERAS_BACKEND']='torch'
from common import *
import torch, keras
from keras import ops
from rdkit import Chem,RDLogger
import deepchem as dc
RDLogger.DisableLog('rdApp.*')

class GraphConv(keras.layers.Layer):
    def __init__(self,units,step_num=1,kernel_regularizer=None,**kw):
        super().__init__(**kw);assert step_num==1;self.units=units;self.reg=kernel_regularizer
    def build(self,shape):
        self.W=self.add_weight(name='W',shape=(shape[0][-1],self.units),initializer='glorot_uniform',regularizer=self.reg)
        self.b=self.add_weight(name='b',shape=(self.units,),initializer='zeros')
    def call(self,inputs):
        x,a=inputs
        return ops.matmul(ops.transpose(a,(0,2,1)),ops.matmul(x,self.W)+self.b)
    def compute_output_shape(self,shape):return tuple(shape[0][:-1])+(self.units,)

source=(OUT/'vendor/CarcGC/Car_model.py').read_text()
source=source.replace('import keras.backend as K','from keras import ops as K').replace('from layers.graph import GraphLayer,GraphConv','')
ns={'GraphConv':GraphConv};exec(compile(source,'Car_model_keras3_compat','exec'),ns)
indexlist=[a for a in range(78) if a not in [9,10,11,12,14,17,18,19,20,21,23,24,25,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42]]
featurizer=dc.feat.ConvMolFeaturizer(use_chirality=True)

def features(s):
    mol=Chem.MolFromSmiles(s);assert mol is not None
    f=featurizer.featurize([mol])[0];x=f.atom_features[:100,indexlist];n=len(x)
    # Final training/prediction notebooks use 100 atoms and truncate; grid notebooks use 200.
    xx=np.zeros((100,len(indexlist)),dtype=np.float32);xx[:n]=x
    a=np.eye(100,dtype=np.float32)
    for i,adj in enumerate(f.canon_adj_list[:100]):a[i,[int(j) for j in adj if int(j)<100]]=1
    diag=np.power(a.sum(1),-.5);a=diag[:,None]*a*diag[None,:]
    return xx,a

def load_split(o,part):
    base=U/f'model/CarcGC/{o}/Dataset';labels=pd.read_csv(base/f'{o}_{part}_data.csv')
    sm=pd.read_csv(base/f'{o}_{"test_" if part=="test" else ""}smiles_data.csv')
    df=labels.merge(sm,on='pert_id',how='left',validate='one_to_one');df[o]=df.Carcinogenicity.map({'+':1,'-':0});assert df[o].notna().all()
    gs=[features(s) for s in df.SMILES]
    return df,[np.stack([g[k] for g in gs]) for k in [0,1]]

class ValidationCallback(keras.callbacks.Callback):
    def __init__(self,x,y,d):super().__init__();self.x=x;self.y=y;self.d=d;self.best=-np.inf;self.bad=0;self.rows=[];self.best_epoch=0
    def on_epoch_end(self,epoch,logs=None):
        p=self.model.predict(self.x,batch_size=8,verbose=0).ravel();auc=roc_auc_score(self.y,p)
        self.rows.append({'epoch':epoch+1,**{k:float(v) for k,v in (logs or {}).items()},'val_auroc':auc})
        pd.DataFrame(self.rows).to_csv(self.d/'history.csv',index=False)
        if auc>self.best:
            self.best=auc;self.bad=0;self.best_epoch=epoch+1;self.model.save_weights(self.d/'best.weights.h5')
        else:self.bad+=1
        if (epoch+1)%10==0:print(self.d.name,epoch+1,'val AUC',auc,'best',self.best,flush=True)
        if self.bad>=80:self.model.stop_training=True

for o in ORGANS:
    d=OUT/'runs'/'CarcGC'/o
    if (d/'metrics.json').exists():continue
    d.mkdir(parents=True,exist_ok=True);seed(1);keras.utils.set_random_seed(1);random.seed(0);np.random.seed(0)
    tr,xt=load_split(o,'train');va,xv=load_split(o,'val');te,xe=load_split(o,'test')
    dropout=.3 if o in ['liv','mgl'] else .5;wd=.0001 if o=='mgl' else .001
    cfg=dict(model='CarcGC',source_commit=(OUT/'vendor/CarcGC/SOURCE_COMMIT.txt').read_text().strip(),source_model_sha256=sha(OUT/'vendor/CarcGC/Car_model.py'),lr=.0001,batch_size=8,dropout=dropout,l2=wd,max_epochs=500,patience=80,selection='validation AUROC',feature_dimensions=len(indexlist),max_atoms=100,graph_units=[256,256,100],backend='Keras 3.12 torch CUDA',train_ids=tr.pert_id.tolist(),val_ids=va.pert_id.tolist(),repairs=['Car_model.py missing from OS repository; supplied by original CarcGC repository','Legacy Keras backend calls mapped to Keras3 ops; original layer architecture retained','TensorFlow1 runtime incompatible with current GPU stack, use Keras3 torch backend; random numbers and optimizer trajectory differ','Retain best-validation weights, do not save every epoch checkpoint','DeepChem2.8/RDKit2025 featurization rather than historic dependencies'],preprocessing='100 atom cap with truncation from final prediction notebooks, not 200 atom grid-search setting')
    cfg['seeds']={'framework':1,'python':0,'numpy':0,'dropout_layer':1}
    dump(d/'config.json',cfg)
    model=ns['KerasMultiSourceGCNModel'](regr=False).createMaster(len(indexlist),[256,256,256],wd,dropout,True,True,True)
    # Verify the graph convolution math against the original formula, independently of training.
    first=next(l for l in model.layers if isinstance(l,GraphConv));w,b=first.get_weights();x=xt[0][:2];a=xt[1][:2]
    expected=a.transpose(0,2,1)@(x@w+b)
    actual=ops.convert_to_numpy(first([x,a]));err=float(np.max(np.abs(actual-expected)));assert err<1e-4
    cfg['graph_operator_max_abs_error']=err;cfg['actual_parameter_device']=str(next(model.parameters()).device)
    assert 'cuda' in cfg['actual_parameter_device'];dump(d/'config.json',cfg)
    model.compile(optimizer=keras.optimizers.Adam(learning_rate=.0001,beta_1=.9,beta_2=.999,epsilon=1e-7,amsgrad=False),loss='binary_crossentropy',jit_compile=False)
    cb=ValidationCallback(xv,va[o].to_numpy(),d)
    model.fit(xt,tr[o].to_numpy(),validation_data=(xv,va[o].to_numpy()),batch_size=8,epochs=500,callbacks=[cb],verbose=0)
    model.load_weights(d/'best.weights.h5');v=va.copy();v['prediction']=model.predict(xv,batch_size=8,verbose=0).ravel()
    cfg.update(best_epoch=cb.best_epoch,epochs_run=len(cb.rows),best_validation_auroc=cb.best)
    save_result('CarcGC',o,te,model.predict(xe,batch_size=8,verbose=0).ravel(),cfg,v)
    keras.backend.clear_session();torch.cuda.empty_cache()
