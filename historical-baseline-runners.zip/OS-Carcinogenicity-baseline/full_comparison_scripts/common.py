"""Frozen official-test comparison, with per-model author training protocols."""
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
import json, hashlib, random, importlib.util
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score, accuracy_score, balanced_accuracy_score, f1_score, matthews_corrcoef, precision_score, recall_score, confusion_matrix

B = Path(__file__).resolve().parents[1]
U = B/'upstream'
OUT = B/'full_comparison_20261101'
ORGANS = ['liv','lun','sto','mgl']

def dump(path, obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False,default=lambda x: x.tolist() if hasattr(x,'tolist') else str(x)))

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def module(path, name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def seed(s):
    import torch
    random.seed(s);np.random.seed(s);torch.manual_seed(s);torch.cuda.manual_seed_all(s)
    torch.set_num_threads(1);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    torch.use_deterministic_algorithms(True,warn_only=True)

def frames(o):
    return (pd.read_csv(U/f'data/single_task/{o}_data(add_reliability)_concat.csv'),pd.read_csv(U/f'data/single_task/test_{o}.csv'))

def metrics(y,p):
    y=np.asarray(y).astype(int);p=np.asarray(p);h=(p>=.5).astype(int)
    tn,fp,fn,tp=confusion_matrix(y,h,labels=[0,1]).ravel()
    return dict(n=len(y),positive=int(y.sum()),negative=int((y==0).sum()),auroc=roc_auc_score(y,p),ap=average_precision_score(y,p),accuracy=accuracy_score(y,h),balanced_accuracy=balanced_accuracy_score(y,h),f1=f1_score(y,h,zero_division=0),mcc=matthews_corrcoef(y,h),precision=precision_score(y,h,zero_division=0),sensitivity=recall_score(y,h,zero_division=0),specificity=float(tn/(tn+fp)),threshold=.5)

def save_result(name,o,df,p,config,val=None):
    d=OUT/'runs'/name/o;d.mkdir(parents=True,exist_ok=True)
    df=df.copy().reset_index(drop=True);df['prediction']=np.asarray(p);df['organ']=o;df['model']=name
    # Preserve original official test row identity, including repeated SMILES.
    full=pd.read_csv(U/'data/multi_task/test_data.csv')
    from collections import defaultdict,deque
    lookup=defaultdict(deque)
    for i,r in full.iterrows():
        if r[o] in [0,1]: lookup[(r.SMILES,int(r[o]))].append(i)
    ids=[]
    for _,r in df.iterrows():
        k=(r.SMILES,int(r[o]));assert lookup[k],(o,k);ids.append(lookup[k].popleft())
    df['official_row']=ids
    assert len(df)==int(full[o].isin([0,1]).sum())
    df.to_csv(d/'test_predictions.csv',index=False)
    result=metrics(df[o],p)
    dump(d/'metrics.json',result);dump(d/'config.json',config)
    if val is not None: val.to_csv(d/'validation_predictions.csv',index=False)
    print(json.dumps({'model':name,'organ':o,**result}),flush=True)
    return result
