"""Usage: python recompute_without_weights.py PATH_TO_EVALUATION_DIRECTORY"""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score,average_precision_score
p=Path(sys.argv[1]);z=np.load(p/'predictions.npz',allow_pickle=True);y=z['labels'];m=pd.read_csv(p/'macro_metrics.csv')
checks=[]
for _,row in m.iterrows():
    scores=[]
    for pred in z[row.model]:
        organs=[]
        for j in range(4):
            ok=y[:,j]>=0
            assert np.isfinite(pred[ok,j]).all()
            organs.append([roc_auc_score(y[ok,j],pred[ok,j]),average_precision_score(y[ok,j],pred[ok,j])])
        scores.append(np.mean(organs,0))
    scores=np.asarray(scores);mean=scores.mean(0)
    for j,key in enumerate(['auroc','ap']):
        err=abs(mean[j]-row[key]);assert err<1e-12,(row.model,key,err)
        checks.append({'model':row.model,'metric':key,'absolute_error':float(err)})
print(json.dumps({'passed':True,'checks':len(checks),'max_abs_error':max(c['absolute_error'] for c in checks)},indent=2))
