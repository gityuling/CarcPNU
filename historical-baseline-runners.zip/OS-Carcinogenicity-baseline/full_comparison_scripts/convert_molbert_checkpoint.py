"""Portable tensor extraction from the original MolBERT Lightning checkpoint.

Source: original README download redirected to the public Figshare S3 object.
https://s3-eu-west-1.amazonaws.com/pfigshare-u-files/25611290/molbert_100epochs.zip
ZIP SHA256: 6d3f5d173c527dc924e82a273ee2b20b36129504e799a254fd362cd8ab081a8b
The source file remains unchanged. Only its old AttributeDict metadata class is mapped.
"""
import pickle,types
from common import *
import torch

class MetadataUnpickler(pickle.Unpickler):
    def find_class(self,module,name):
        if module=='pytorch_lightning.utilities.parsing' and name=='AttributeDict':return dict
        return super().find_class(module,name)

compat=types.ModuleType('molbert_checkpoint_compat')
compat.Unpickler=MetadataUnpickler;compat.load=pickle.load
p=OUT/'vendor/molbert_100epochs/checkpoints/last.ckpt'
checkpoint=torch.load(p,map_location='cpu',weights_only=False,pickle_module=compat)
target=p.parent.parent/'encoder_state_dict.pt'
torch.save(checkpoint['state_dict'],target)
dump(OUT/'molbert_checkpoint_provenance.json',dict(source='https://ndownloader.figshare.com/files/25611290',public_object='https://s3-eu-west-1.amazonaws.com/pfigshare-u-files/25611290/molbert_100epochs.zip',source_sha256=sha(p),tensor_copy_sha256=sha(target),state_dict_tensors=len(checkpoint['state_dict']),metadata_compatibility='Only Lightning AttributeDict mapped to dict',pretrained_epoch=checkpoint['epoch']))
