"""Provenance, official-test alignment and reuse of already executed multi-task fits."""
from common import *
from rdkit import Chem,RDLogger
RDLogger.DisableLog('rdApp.*')
from collections import Counter

def canon(s):return Chem.MolToSmiles(Chem.MolFromSmiles(s))

audit={}
pool=json.loads((B.parent/'OS-Carcinogenicity-G2CP/phase4_evidence_20261031/pool.json').read_text())
our=set(map(canon,pool['smiles']))
for o in ORGANS:
    tr,te=frames(o);c=list(map(canon,tr.SMILES));t=list(map(canon,te.SMILES))
    audit[o]=dict(author_concat_rows=len(tr),author_concat_unique_canonical=len(set(c)),our_previous_training_pool_unique_canonical=len(our),author_structures_outside_previous_pool=len(set(c)-our),test_rows=len(te),test_positive=int(te[o].sum()),test_negative=int((te[o]==0).sum()),test_overlap_author_training_rows=sum(s in set(c) for s in t),train_sha256=sha(U/f'data/single_task/{o}_data(add_reliability)_concat.csv'),test_sha256=sha(U/f'data/single_task/test_{o}.csv'))
dump(OUT/'data_provenance_audit.json',audit)

for name,path in [('multi_task_published',B/'artifacts/published_checkpoint'),('multi_task_retrained',B/'runs/author_gpu_01/external_test'),('multi_task_repeat',B/'runs/author_gpu_repeat_01/external_test')]:
    pred=pd.read_csv(path/'predictions.csv');assert len(pred)==454
    for o in ORGANS:
        _,te=frames(o);sub=pred.loc[pred[f'label_{o}'].isin([0,1])].copy();sub[o]=sub[f'label_{o}']
        assert Counter(zip(sub.SMILES,sub[o]))==Counter(zip(te.SMILES,te[o]))
        cfg=dict(model=name,execution='Previously completed GPU inference' if name.endswith('published') else 'Previously completed GPU training from scratch; existing complete run reused without score-based selection',source_prediction_file=str(path/'predictions.csv'),source_prediction_sha256=sha(path/'predictions.csv'),source_metrics=str(path/'metrics.json'),source_metrics_sha256=sha(path/'metrics.json'),notes='Published checkpoint matches eight paper AUROC/AP numbers; random-initialized fits do not numerically reproduce all paper metrics. Both initial run and repeat are retained.')
        save_result(name,o,sub[['SMILES',o]],sub[f'prob_{o}'].to_numpy(),cfg)

# Correct the provenance note for RF stomach's missing non-concat input (data unchanged).
p=OUT/'runs/RF/sto/config.json'
if p.exists():
    c=json.loads(p.read_text());note='Author stomach RF references absent sto_data(add_reliability).csv; released concat table was used. This is a documented reconstruction, not exact historical training-set recovery.'
    if note not in c['repairs']:c['repairs'].append(note)
    dump(p,c)

paper={
 'multi_task':[[.7023,.9646],[.7486,.8907],[.7636,.8914],[.6813,.7408]],
 'single_task':[[.5576,.9505],[.6789,.8255],[.7055,.8085],[.6240,.7613]],
 'MolBERT':[[.6613,.9566],[.7146,.8744],[.7091,.8844],[.7508,.8385]],
 'CarcGC':[[.6196,.9495],[.7301,.8685],[.7418,.8846],[.5512,.7316]],
 'DCAMCP':[[.5502,.9373],[.6384,.8377],[.5527,.6881],[.5895,.7206]],
 'XGBoost':[[.5651,.9554],[.6272,.8562],[.6872,.8652],[.5874,.7330]],
 'RF':[[.6211,.9621],[.6870,.8691],[.6709,.8338],[.7241,.8174]]}
dump(OUT/'paper_table7.json',dict(source='https://pmc.ncbi.nlm.nih.gov/articles/PMC13273428/',organs=ORGANS,metric_order=['auroc','ap'],values=paper))
protocol=dict(request='Run all seven official baseline models; completeness first. Existing valid runs may be reused after audit.',primary_test='Original official 454 rows; per-organ labels unchanged; 311/211/36/89 observed labels',test_sha256=sha(U/'data/multi_task/test_data.csv'),required_models=list(paper),additional_diagnostic_models=['DCAMCP_corrected','multi_task_repeat','multi_task_published'],training='Follow each released organ comparator split and selected configuration; no new test split and no PNU retuning',model_selection='Use released final parameters; checkpoints selected with internal validation only',comparison_boundary='Official single-task comparator tables contain more structures than prior 435-parent PNU pool. Same official test, not identical training data or tuning budget. Published values and local adapted retraining values are separate.',PNU='Fixed previously chosen expanded-U PNU; selection history exposed in prior phase4 protocol; original test has already been inspected',compatibility='Modern GPU adaptations and missing-file repairs are enumerated per run; completion is execution coverage, not exact recovery of every original score',execution='Single GPU training process at a time; RF native CPU with two threads; neural and XGB models CUDA',source_commit='633bbd7294e5b67ae537b88c5f75eb8c53abd454')
protocol['DCAMCP_reporting']='Corrected fingerprint alignment, no identifier feature, correct CapsuleLoss arguments is the primary adapted comparator; original code logic retained separately as diagnostic. Decision based on source audit before corrected fit.'
dump(OUT/'protocol.json',protocol)
print('Provenance audit and three existing multi-task result sets imported.')
