"""Author DCAMCP parameters, with verified torch graph execution for modern CUDA."""
import types, argparse, copy
from common import *
import torch
import torch.nn.functional as F
import dgl
from dgllife.utils import smiles_to_bigraph,CanonicalAtomFeaturizer,CanonicalBondFeaturizer
from torch_geometric.data import Data,Batch
from torch_geometric.loader import DataLoader
from torch_geometric.utils import softmax,scatter
from rdkit import RDLogger
RDLogger.DisableLog('rdApp.*')

def gat_forward(self,g,fps):
    x=g.x;src,dst=g.edge_index
    for layer in self.gnn_layers.gnn_layers:
        c=layer.gat_conv;h=c.feat_drop(x);z=c.fc(h).view(-1,c._num_heads,c._out_feats)
        el=(z*c.attn_l).sum(-1);er=(z*c.attn_r).sum(-1)
        a=c.attn_drop(softmax(c.leaky_relu(el[src]+er[dst]),dst,num_nodes=len(x)))
        zsum=scatter(z[src]*a.unsqueeze(-1),dst,dim=0,dim_size=len(x),reduce='sum')
        if c.res_fc is not None:zsum=zsum+c.res_fc(h).view(len(x),-1,c._out_feats)
        if c.has_explicit_bias:zsum=zsum+c.bias.view(1,c._num_heads,c._out_feats)
        if c.activation:zsum=c.activation(zsum)
        x=zsum.flatten(1) if layer.agg_mode=='flatten' else zsum.mean(1)
        if layer.activation:x=layer.activation(x)
    # Native per-graph max is exactly the DGL MaxPooling operation.
    pooled=torch.stack([a.amax(0) for a in torch.split(x,g.ptr.diff().tolist())])
    return self.linear(torch.cat([pooled,fps],dim=-1))

def convert(g,fp,y):
    return Data(x=g.ndata['h'],edge_index=torch.stack(g.edges()).long(),fp=torch.tensor(np.asarray(fp),dtype=torch.float32).unsqueeze(0),y=torch.tensor([y],dtype=torch.long))

def verify(author):
    seed(2);author.device=torch.device('cpu')
    m=author.Mymodel(74,1025).eval();p=copy.deepcopy(m);p.GAT.forward=types.MethodType(gat_forward,p.GAT)
    gs=[smiles_to_bigraph(s,add_self_loop=True,node_featurizer=CanonicalAtomFeaturizer(),canonical_atom_order=False) for s in ['CCO','c1ccccc1','CC(=O)O']]
    fp=torch.randn(3,1025);g=dgl.batch(gs);pg=Batch.from_data_list([convert(x,fp[i],i%2) for i,x in enumerate(gs)])
    a=m(g,fp);b=p(pg,fp);err=float((a-b).abs().max())
    a.sum().backward();b.sum().backward()
    ge=max(float((q.grad-r.grad).abs().max()) for q,r in zip(m.parameters(),p.parameters()) if q.grad is not None)
    assert err<1e-5 and ge<1e-4,(err,ge)
    dump(OUT/'dcamcp_operator_equivalence.json',dict(forward_max_abs_error=err,gradient_max_abs_error=ge,reference='unmodified author model + DGL 1.1.3 CPU',execution='same weights and layers, torch scatter graph operator',note='Forward/gradient verification only; no CPU training comparison'))

parser=argparse.ArgumentParser();parser.add_argument('--corrected',action='store_true');args=parser.parse_args()
name='DCAMCP_corrected' if args.corrected else 'DCAMCP'
author=module(U/'model/DCAMCP/liv/model.py','author_dca');verify(author)
# Algebraically identical reciprocal-exp replacement prevents overflow in backward.
def stable_squash(x,dim=-1):
    norm2=(x*x).sum(dim=dim,keepdim=True)
    return (-torch.expm1(-norm2.clamp_min(1e-16).sqrt()))*x/(norm2+1e-8).sqrt()
author.squash2=stable_squash
for o in ORGANS:
    d=OUT/'runs'/name/o
    if (d/'metrics.json').exists():continue
    d.mkdir(parents=True,exist_ok=True)
    tr,te=frames(o);n=len(tr)
    s=pd.read_csv(U/f'model/DCAMCP/{o}/smiles.csv');f=pd.read_csv(U/f'model/DCAMCP/{o}/CDKExt.csv')
    assert s.smiles.tolist()==tr.SMILES.tolist()+te.SMILES.tolist()
    assert s.Class.tolist()==tr[o].tolist()+te[o].tolist()
    if args.corrected:
        f=f.sort_values('Name');assert f.Name.tolist()==list(range(1,len(f)+1));f=f.drop(columns='Name')
    fp=f.to_numpy(dtype=np.float32)
    gs=[smiles_to_bigraph(x,add_self_loop=True,node_featurizer=CanonicalAtomFeaturizer(),edge_featurizer=CanonicalBondFeaturizer(self_loop=True),canonical_atom_order=False) for x in s.smiles]
    data=[convert(g,fp[i],s.Class.iloc[i]) for i,g in enumerate(gs)]
    y=tr[o].to_numpy().astype(int);rng=np.random.RandomState(2)
    i0=np.flatnonzero(y==0).tolist();i1=np.flatnonzero(y==1).tolist();rng.shuffle(i0);rng.shuffle(i1)
    k0=int(len(i0)*.2);k1=int(len(i1)*.2);vi=i0[:k0]+i1[:k1];ti=i0[k0:]+i1[k1:];rng.shuffle(vi);rng.shuffle(ti)
    cfg=dict(model=name,seed=2,train_indices=ti,validation_indices=vi,max_epochs=100,patience=50,batch_size=2,drop_last=True,lr=.001,weight_decay=.00001,dropout=.2,device='cuda:0',feature_columns=len(f.columns),graph_operator='verified torch equivalent of original DGL GAT, same parameter objects',source_sha256=sha(U/f'model/DCAMCP/{o}/model.py'),repairs=['remove obsolete scheduler verbose argument','always reload best validation-AUROC checkpoint, including when max_epochs reached'],author_issues=['CDKExt Name identifier included as feature','CDKExt rows are lexicographic by Name but original smiles rows are numeric order','CapsuleLoss signature(labels,logits) but notebook calls(logits,labels)'],issues_corrected=args.corrected)
    cfg['repairs'].append('squash reciprocal exp rewritten as -expm1(-norm); norm2 clamped at 1e-16 in numerator to prevent undefined sqrt gradient at zero')
    dump(d/'config.json',cfg)
    seed(2);author.device=torch.device('cuda');model=author.Mymodel(74,fp.shape[1]).cuda();model.GAT.forward=types.MethodType(gat_forward,model.GAT)
    criterion=author.CapsuleLoss();opt=torch.optim.Adam(model.parameters(),lr=.001,weight_decay=.00001)
    scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,mode='max',factor=.5,patience=50)
    tl=DataLoader([data[i] for i in ti],batch_size=2,shuffle=True,drop_last=True);vl=DataLoader([data[i] for i in vi],batch_size=2)
    def evaluate(items):
        model.eval();p=[];losses=[]
        with torch.no_grad():
            for g in DataLoader(items,batch_size=2):
                g=g.cuda();z=model(g,g.fp);p.extend(z[:,1].cpu().tolist());oh=F.one_hot(g.y,2).float()
                losses.append(float(criterion(oh,z) if args.corrected else criterion(z,oh)))
        return np.array(p),float(np.mean(losses))
    history=[];best=-float('inf');bad=0
    for ep in range(1,101):
        model.train();losses=[]
        for g in tl:
            g=g.cuda();opt.zero_grad();z=model(g,g.fp);oh=F.one_hot(g.y,2).float()
            loss=criterion(oh,z) if args.corrected else criterion(z,oh)
            loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.,error_if_nonfinite=True);opt.step();losses.append(float(loss.detach()))
        vp,vloss=evaluate([data[i] for i in vi]);auc=roc_auc_score(y[vi],vp);scheduler.step(auc)
        history.append(dict(epoch=ep,train_loss=np.mean(losses),val_loss=vloss,val_auroc=auc))
        if auc>best:best=auc;bad=0;bestep=ep;torch.save(model.state_dict(),d/'best.pt')
        else:bad+=1
        pd.DataFrame(history).to_csv(d/'history.csv',index=False)
        if ep%10==0:print(name,o,ep,'val AUC',auc,flush=True)
        if bad>=50:break
    model.load_state_dict(torch.load(d/'best.pt',weights_only=True));vp,_=evaluate([data[i] for i in vi]);v=tr.iloc[vi].copy();v['prediction']=vp
    cfg.update(best_epoch=bestep,epochs_run=ep,best_validation_auroc=best)
    p,_=evaluate(data[n:]);save_result(name,o,te,p,cfg,v)
