"""Full MolBERT finetuning using author tokenizer/datasets and pretrained encoder."""
import sys, math, logging, gc
from common import *
import torch
from torch import nn
from torch.utils.data import Subset
from transformers import BertModel,BertConfig,get_linear_schedule_with_warmup
sys.path.insert(0,str(OUT/'vendor/MolBERT'))
from molbert.utils.featurizer.molfeaturizer import SmilesIndexFeaturizer
from molbert.datasets.finetune import BertFinetuneSmilesDataset
from molbert.datasets.dataloading import MolbertDataLoader
logging.getLogger().setLevel(logging.ERROR)

class Position(nn.Module):
    def __init__(self,d):
        super().__init__();self.register_buffer('inv_freq',1/(10000**(torch.arange(0,d,2).float()/d)))
    def forward(self,pos,bs):
        s=torch.outer(pos,self.inv_freq);return torch.cat([s.sin(),s.cos()],-1).unsqueeze(0).expand(bs,-1,-1)

class Embeddings(nn.Module):
    def __init__(self,c):
        super().__init__();self.word_embeddings=nn.Embedding(c.vocab_size,c.hidden_size,padding_idx=0)
        self.position_embeddings=Position(c.hidden_size);self.token_type_embeddings=nn.Embedding(c.type_vocab_size,c.hidden_size)
        self.LayerNorm=nn.LayerNorm(c.hidden_size,eps=c.layer_norm_eps);self.dropout=nn.Dropout(c.hidden_dropout_prob)
    def forward(self,input_ids=None,token_type_ids=None,position_ids=None,inputs_embeds=None,past_key_values_length=0):
        w=self.word_embeddings(input_ids) if inputs_embeds is None else inputs_embeds
        if token_type_ids is None:token_type_ids=torch.zeros(w.shape[:2],dtype=torch.long,device=w.device)
        pos=torch.arange(w.shape[1],dtype=w.dtype,device=w.device)
        return self.dropout(self.LayerNorm(w+self.position_embeddings(pos,w.shape[0])+self.token_type_embeddings(token_type_ids)))

class MolBERT(nn.Module):
    def __init__(self,weights):
        super().__init__()
        # Author constructs FinetuneHead before the pretrained encoder.
        self.head=nn.Linear(768,2)
        c=BertConfig(vocab_size=42,hidden_size=768,num_hidden_layers=12,num_attention_heads=12,intermediate_size=3072,max_position_embeddings=512,return_dict=False,attn_implementation='eager')
        self.bert=BertModel(c);self.bert.embeddings=Embeddings(c)
        expected={k[len('model.bert.'):]:v for k,v in weights.items() if k.startswith('model.bert.')}
        self.bert.load_state_dict(expected,strict=True)
    def forward(self,x):return self.head(self.bert(**x,return_dict=False)[1])

ckpt=OUT/'vendor/molbert_100epochs/checkpoints/last.ckpt'
weights=torch.load(ckpt.parent.parent/'encoder_state_dict.pt',map_location='cpu',weights_only=True)
f=SmilesIndexFeaturizer.bert_smiles_index_featurizer(128)

def dataset(path,o,inference=False):
    return BertFinetuneSmilesDataset(input_path=str(path),featurizer=f,single_seq_len=128,total_seq_len=128,label_column=o,is_same=False,inference_mode=inference)

for o in ORGANS:
    d=OUT/'runs'/'MolBERT'/o
    if (d/'metrics.json').exists():continue
    d.mkdir(parents=True,exist_ok=True);seed(42)
    tr,te=frames(o)
    # Actual CSV split shipped by OS authors, rather than a newly generated split.
    train=pd.read_csv(U/f'data/single_task/split_csv/train_{o}_7_3.csv').rename(columns={'label':o})
    val=pd.read_csv(U/f'data/single_task/split_csv/val_{o}_7_3.csv').rename(columns={'label':o})
    assert len(train)+len(val)==len(tr)
    for part,df in [('train',train),('val',val),('test',te)]:df.to_csv(d/f'{part}_input.csv',index=False)
    td=dataset(d/'train_input.csv',o);vd=dataset(d/'val_input.csv',o);ed=dataset(d/'test_input.csv',o,True)
    tv=np.array([td.get_sample(i)[3] for i in range(len(td))]);vv=np.array([vd.get_sample(i)[3] for i in range(len(vd))]);ev=np.array([ed.get_sample(i)[3] for i in range(len(ed))])
    cfg=dict(model='MolBERT',source_commit=(OUT/'vendor/MolBERT/SOURCE_COMMIT.txt').read_text().strip(),pretrained_sha256=sha(ckpt),seed=42,split='released train/val 7_3 CSV',batch_size=32,learning_rate=.00003,weight_decay=.01,adam_epsilon=1e-8,warmup_proportion=.1,max_epochs=20,max_seq_length=128,precision='float32',train_encoder=True,validation_interval=.25,selection='minimum masked validation cross-entropy',train_n=len(td),val_n=len(vd),train_encodable=int(tv.sum()),val_encodable=int(vv.sum()),test_encodable=int(ev.sum()),test_unencodable_rows=np.flatnonzero(~ev),repairs=['Legacy Lightning training loop replaced by explicit torch loop; author tokenizer, masking, datasets, transformer architecture and checkpoint retained','Modern transformers eager attention and torch AdamW used; not bitwise legacy-runtime reproduction','Inference minibatched at 32 to bound GPU memory','Unsupported test structures explicitly flagged; full official-test summary uses training prevalence fallback, native supported-subset results saved separately'])
    fallback=float(train.loc[tv,o].mean());cfg['unsupported_fallback_training_prevalence']=fallback
    dump(d/'config.json',cfg)
    model=MolBERT(weights).cuda();torch.cuda.set_per_process_memory_fraction(.75)
    no_decay=['bias','LayerNorm.weight'];params=[{'params':[p for n,p in model.named_parameters() if not any(x in n for x in no_decay)],'weight_decay':.01},{'params':[p for n,p in model.named_parameters() if any(x in n for x in no_decay)],'weight_decay':0.}]
    opt=torch.optim.AdamW(params,lr=3e-5,eps=1e-8)
    total=(len(td)//32)*20;scheduler=get_linear_schedule_with_warmup(opt,num_warmup_steps=int(total*.1),num_training_steps=total)
    tl=MolbertDataLoader(td,batch_size=32,shuffle=True,num_workers=0)
    def evaluate(ds,mask):
        model.eval();ps=[];losses=[]
        with torch.no_grad():
            for (x,y),_ in MolbertDataLoader(Subset(ds,np.flatnonzero(mask)),batch_size=32,num_workers=0):
                z=model({k:v.cuda() for k,v in x.items()});target=y['finetune'].long().squeeze(1).cuda()
                losses.append(float(nn.functional.cross_entropy(z,target)));ps.extend(z.softmax(-1)[:,1].cpu().tolist())
        return np.asarray(ps),float(np.mean(losses))
    best=float('inf');history=[];step=0;check_every=max(1,int(len(tl)*.25));bestep=0
    for ep in range(1,21):
        model.train();losses=[]
        for bi,((x,y),_) in enumerate(tl,1):
            opt.zero_grad();z=model({k:v.cuda() for k,v in x.items()});loss=nn.functional.cross_entropy(z,y['finetune'].long().squeeze(1).cuda())
            assert torch.isfinite(loss);loss.backward();opt.step();scheduler.step();step+=1;losses.append(float(loss.detach()))
            if bi%check_every==0 or bi==len(tl):
                vp,vloss=evaluate(vd,vv);history.append(dict(epoch=ep,batch=bi,step=step,train_loss=np.mean(losses),val_loss=vloss,learning_rate=opt.param_groups[0]['lr']))
                if vloss<best:
                    best=vloss;bestep=ep;torch.save(model.state_dict(),d/'best.pt')
                pd.DataFrame(history).to_csv(d/'history.csv',index=False);model.train()
        print('MolBERT',o,ep,'train',np.mean(losses),'val',vloss,'best',best,flush=True)
    model.load_state_dict(torch.load(d/'best.pt',map_location='cpu',weights_only=True));vp,_=evaluate(vd,vv);v=val.loc[vv].copy();v['prediction']=vp
    native,_=evaluate(ed,ev);p=np.full(len(te),fallback);p[ev]=native
    dump(d/'native_supported_metrics.json',metrics(te.loc[ev,o],native))
    pred_df=te.copy();pred_df['encoder_supported']=ev;pred_df['fallback_used']=~ev
    cfg.update(best_epoch=bestep,best_validation_loss=best,epochs_run=20)
    save_result('MolBERT',o,pred_df,p,cfg,v)
    del model,opt,scheduler;gc.collect();torch.cuda.empty_cache()
