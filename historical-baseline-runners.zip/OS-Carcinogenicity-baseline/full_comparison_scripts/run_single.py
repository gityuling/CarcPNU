import ast, copy, time
from common import *
import torch
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
from sklearn.model_selection import StratifiedShuffleSplit
from rdkit import RDLogger
RDLogger.DisableLog('rdApp.*')

src=next((OUT/'source_notebooks').glob('single_task__single_task_molecular*')).read_text()
ns={}
tree=ast.parse(src)
safe=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))]
exec(compile(ast.Module(body=safe,type_ignores=[]),'author_featurizer','exec'),ns)

def graphs(df,o):
    data=[];valid=[]
    for i,r in df.iterrows():
        g=ns['smile_to_graph'](r.SMILES)
        if g is None: continue
        n,x,e=g
        data.append(Data(x=torch.tensor(np.asarray(x),dtype=torch.float32),edge_index=torch.tensor(e).T.contiguous(),y=torch.tensor([r[o]],dtype=torch.float32)))
        valid.append(i)
    return data,valid

for o in ORGANS:
    d=OUT/'runs'/'single_task'/o
    if (d/'metrics.json').exists():continue
    d.mkdir(parents=True,exist_ok=True);seed(2)
    author=module(U/f'model/single_task/{o}/utils.py',f'single_{o}')
    tr,te=frames(o);data,valid=graphs(tr,o);tr=tr.iloc[valid].reset_index(drop=True)
    tdata,tvalid=graphs(te,o);assert len(tvalid)==len(te),'No silent test exclusions'
    ti,vi=next(StratifiedShuffleSplit(n_splits=1,test_size=.3,random_state=1).split(np.zeros(len(tr)),tr[o]))
    cfg=dict(model='single_task',seed=2,split_seed=1,val_ratio=.3,output_dim=16,dropout=.3,batch_size=2,lr=.001,wd=.0001 if o=='lun' else .00001,max_epochs=1000,patience=10,focal_alpha=.25,focal_gamma=2,device='cuda:0',source_sha256=sha(U/f'model/single_task/{o}/utils.py'),train_indices=ti,validation_indices=vi,source_valid_rows=valid,repairs=['cuda:1 mapped to available cuda:0','missing single-task cache regenerated with original featurizer and current RDKit','sigmoid probabilities retained directly; omitted duplicate sigmoid in author evaluation (AUROC/AP ranks unchanged)'])
    dump(d/'config.json',cfg)
    model=author.single_task(52,2,16,.3).cuda();loss_fn=author.FocalLoss(alpha=.25,gamma=2,reduction='mean')
    opt=torch.optim.Adam(model.parameters(),lr=cfg['lr'],weight_decay=cfg['wd'])
    tl=DataLoader([data[i] for i in ti],batch_size=2,shuffle=True)
    vl=DataLoader([data[i] for i in vi],batch_size=2,shuffle=False)
    best=float('inf');bad=0;history=[]
    for ep in range(1,1001):
        trainloss=author.train_single_task(ep,model,loss_fn,opt,'cuda',tl)
        valloss=author.val_single_task(ep,model,loss_fn,'cuda',vl)
        history.append(dict(epoch=ep,train_loss=trainloss,val_loss=valloss))
        if valloss<=best:
            best=valloss;bad=0;torch.save(model.state_dict(),d/'best.pt');bestep=ep
        else:bad+=1
        pd.DataFrame(history).to_csv(d/'history.csv',index=False)
        if ep%10==0:print(o,ep,trainloss,valloss,flush=True)
        if bad>=10:break
    model.load_state_dict(torch.load(d/'best.pt',weights_only=True));model.eval()
    def predict(gs):
        with torch.no_grad():return np.concatenate([model(x.cuda())[0].cpu().numpy().ravel() for x in DataLoader(gs,batch_size=2)])
    vp=predict([data[i] for i in vi]);v=tr.iloc[vi].copy();v['prediction']=vp
    cfg.update(best_epoch=bestep,epochs_run=ep,best_validation_loss=best)
    save_result('single_task',o,te,predict(tdata),cfg,v)
