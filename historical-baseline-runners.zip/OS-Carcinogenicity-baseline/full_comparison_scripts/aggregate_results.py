"""Recompute all scores from preserved predictions; no weights or fitting needed."""
from common import *
import argparse
from sklearn.metrics import roc_auc_score,average_precision_score
PAPER=json.loads((OUT/'paper_table7.json').read_text())['values']
NAMES={'multi_task_published':'多任务 作者权重','multi_task_retrained':'多任务 本地从头训练','multi_task_repeat':'多任务 本地训练重复','single_task':'单任务 GAT','MolBERT':'MolBERT','CarcGC':'CarcGC','DCAMCP':'DCAMCP 原脚本逻辑','DCAMCP_corrected':'DCAMCP 修正版','XGBoost':'XGBoost','RF':'作者 RF','fusion_supervised':'结构增强 普通监督','fusion_pnu':'结构增强 PNU','fusion_downweight':'结构增强 阴性降权'}
ORDER=list(NAMES)
parser=argparse.ArgumentParser();parser.add_argument('--partial',action='store_true');parser.add_argument('--bootstrap',type=int,default=2000);args=parser.parse_args()
test=pd.read_csv(U/'data/multi_task/test_data.csv');Y=test[ORGANS].fillna(-1).to_numpy().astype(int)
predictions={};organ_rows=[];macro_rows=[];coverage=[]
for name in ORDER[:10]:
    paths=[OUT/'runs'/name/o/'test_predictions.csv' for o in ORGANS]
    if not all(p.exists() for p in paths):
        if args.partial:continue
        raise RuntimeError(f'Incomplete required run {name}')
    p=np.full(Y.shape,np.nan)
    for j,(o,path) in enumerate(zip(ORGANS,paths)):
        df=pd.read_csv(path);idx=df.official_row.to_numpy();y=df[o].to_numpy().astype(int);assert len(np.unique(idx))==len(idx)
        assert np.array_equal(Y[idx,j],y);assert df.SMILES.tolist()==test.SMILES.iloc[idx].tolist()
        p[idx,j]=df.prediction.to_numpy();assert np.isfinite(p[Y[:,j]>=0,j]).all()
        assert len(df)==int((Y[:,j]>=0).sum())
        coverage.append(dict(model=name,organ=o,expected=int((Y[:,j]>=0).sum()),actual=len(df),finite=bool(np.isfinite(df.prediction).all()),prediction_sha256=sha(path)))
    predictions[name]=p[None,:,:]

phase=B.parent/'OS-Carcinogenicity-G2CP/phase4_evidence_20261031/evaluation'
z=np.load(phase/'original_predictions.npz',allow_pickle=True)
assert np.array_equal(Y,z['labels']);assert test.SMILES.tolist()==list(z['smiles'])
for name in ORDER[10:]:predictions[name]=z[name]

def macro(y,p):
    result=[]
    for j in range(4):
        mask=y[:,j]>=0
        if len(np.unique(y[mask,j]))<2:return np.array([np.nan,np.nan])
        result.append([roc_auc_score(y[mask,j],p[mask,j]),average_precision_score(y[mask,j],p[mask,j])])
    return np.mean(result,0)

for name,ps in predictions.items():
    seed_macro=[]
    for si,p in enumerate(ps):
        local=[]
        for j,o in enumerate(ORGANS):
            mask=Y[:,j]>=0;m=metrics(Y[mask,j],p[mask,j]);local.append(m)
            organ_rows.append(dict(model=name,model_cn=NAMES[name],seed_index=si,organ=o,**m))
        seed_macro.append({k:np.mean([m[k] for m in local]) for k in ['auroc','ap']})
    macro_rows.append(dict(model=name,model_cn=NAMES[name],fits=len(ps),auroc=float(np.mean([x['auroc'] for x in seed_macro])),ap=float(np.mean([x['ap'] for x in seed_macro])),auroc_sd=float(np.std([x['auroc'] for x in seed_macro],ddof=1)) if len(ps)>1 else None,ap_sd=float(np.std([x['ap'] for x in seed_macro],ddof=1)) if len(ps)>1 else None))

summary=pd.DataFrame(macro_rows);perorgan=pd.DataFrame(organ_rows)
(OUT/'evaluation').mkdir(exist_ok=True)
summary.to_csv(OUT/'evaluation/macro_metrics.csv',index=False);perorgan.to_csv(OUT/'evaluation/per_organ_metrics.csv',index=False)
np.savez_compressed(OUT/'evaluation/predictions.npz',labels=Y,smiles=test.SMILES.to_numpy(),**predictions)
dump(OUT/'evaluation/coverage_audit.json',coverage)

paper_rows=[]
for name,vals in PAPER.items():
    local={'multi_task':'multi_task_retrained','DCAMCP':'DCAMCP_corrected'}.get(name,name)
    if local not in predictions:continue
    row=summary.set_index('model').loc[local]
    paper_rows.append(dict(model=name,paper_auroc=np.mean(vals,axis=0)[0],paper_ap=np.mean(vals,axis=0)[1],local_auroc=row.auroc,local_ap=row.ap,local_model=local))
pd.DataFrame(paper_rows).to_csv(OUT/'evaluation/paper_vs_local.csv',index=False)

# Explicitly compare every model on the same MolBERT-supported subset as an additional coverage audit.
supported=np.ones(Y.shape,dtype=bool)
if 'MolBERT' in predictions:
    for j,o in enumerate(ORGANS):
        df=pd.read_csv(OUT/'runs/MolBERT'/o/'test_predictions.csv');supported[df.official_row,j]=df.encoder_supported.to_numpy()
    yy=Y.copy();yy[~supported]=-1;rows=[]
    for name,ps in predictions.items():
        score=np.mean([macro(yy,p) for p in ps],axis=0);rows.append(dict(model=name,auroc=score[0],ap=score[1]))
    pd.DataFrame(rows).to_csv(OUT/'evaluation/common_molbert_supported_subset.csv',index=False)

if not args.partial:
    # Whole official rows are resampled jointly across organs. Multiple PNU seeds are averaged as scores.
    keys=['fusion_pnu']+[n for n in predictions if n!='fusion_pnu']
    rng=np.random.default_rng(20261101);draws={n:[] for n in keys};valid_draws=0
    for k in range(args.bootstrap):
        if k%100==0:print(f'Paired bootstrap {k}/{args.bootstrap}',flush=True)
        ix=rng.integers(0,len(Y),len(Y));yy=Y[ix]
        if any(len(np.unique(yy[yy[:,j]>=0,j]))<2 for j in range(4)):continue
        valid_draws+=1
        for name in keys:draws[name].append(np.mean([macro(yy,p[ix]) for p in predictions[name]],axis=0))
    paired=[];means=summary.set_index('model')
    for n in keys[1:]:
        delta=np.asarray(draws['fusion_pnu'])-np.asarray(draws[n]);ci=np.quantile(delta,[.025,.975],axis=0)
        paired.append(dict(base=n,delta_auroc=means.loc['fusion_pnu','auroc']-means.loc[n,'auroc'],auroc_ci_low=ci[0,0],auroc_ci_high=ci[1,0],delta_ap=means.loc['fusion_pnu','ap']-means.loc[n,'ap'],ap_ci_low=ci[0,1],ap_ci_high=ci[1,1]))
    pd.DataFrame(paired).to_csv(OUT/'evaluation/pnu_paired_bootstrap.csv',index=False)
    dump(OUT/'evaluation/bootstrap_protocol.json',dict(repetitions=args.bootstrap,valid_repetitions=valid_draws,seed=20261101,unit='official compound row jointly over organs',interpretation='Conditional on fitted models; PNU across-seed metric mean; no correction for historical tuning or multiple testing; different author training pools remain'))
dump(OUT/'evaluation/summary.json',dict(partial=args.partial,macro=macro_rows,names=NAMES,order=ORDER,paper_vs_local=paper_rows,coverage=coverage))
print(summary[['model','auroc','ap']].to_string(index=False))
