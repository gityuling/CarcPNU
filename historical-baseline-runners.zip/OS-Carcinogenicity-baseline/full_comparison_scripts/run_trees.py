import argparse, joblib
from common import *
from rdkit import Chem, DataStructs, RDLogger
from rdkit.Chem import AllChem, QED
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split,StratifiedShuffleSplit
RDLogger.DisableLog('rdApp.*')

def features(df):
    bits=[];props=[]
    for s in df.SMILES:
        mol=Chem.MolFromSmiles(s);assert mol is not None
        a=np.zeros(1024,dtype=np.float32)
        DataStructs.ConvertToNumpyArray(AllChem.GetMorganFingerprintAsBitVect(mol,2,nBits=1024),a)
        bits.append(a);props.append(list(QED.properties(mol)))
    # Author pandas QED columns are float64 until the final concatenated float32 tensor.
    return np.array(bits),np.array(props,dtype=np.float64)

rfparams=[dict(n_estimators=150,max_depth=20,min_samples_split=5,max_features='sqrt'),dict(n_estimators=100,max_depth=20,min_samples_split=2,max_features='sqrt'),dict(n_estimators=100,max_depth=None,min_samples_split=2,max_features='log2'),dict(n_estimators=50,max_depth=None,min_samples_split=5,max_features='sqrt')]
xgparams=[dict(n_estimators=100,max_depth=3,subsample=1.,colsample_bytree=1.),dict(n_estimators=200,max_depth=6,subsample=.8,colsample_bytree=.8),dict(n_estimators=200,max_depth=6,subsample=1.,colsample_bytree=.8),dict(n_estimators=100,max_depth=3,subsample=1.,colsample_bytree=1.)]
parser=argparse.ArgumentParser();parser.add_argument('--model',choices=['RF','XGBoost'],required=True);args=parser.parse_args()
for j,o in enumerate(ORGANS):
    name=args.model;d=OUT/'runs'/name/o
    if (d/'metrics.json').exists():continue
    d.mkdir(parents=True,exist_ok=True)
    tr,te=frames(o);y=tr[o].to_numpy().astype(int);fp,q=features(tr);ft,qt=features(te)
    if name=='RF':
        ratio=[.3,.3,.1,.3][j];splitseed=[0,42,0,4][j]
        ti,vi=train_test_split(np.arange(len(y)),test_size=ratio,random_state=splitseed,stratify=y)
        scaler=StandardScaler().fit(q[ti]);params=rfparams[j]
        model=RandomForestClassifier(random_state=42,n_jobs=2,class_weight='balanced',bootstrap=True,**params)
        repairs=['Use selected parameters printed in released training notebook output, not fallback parameters; selected pkl was not released','Paths resolved to released single_task concat tables; CPU native sklearn RF, no CPU/GPU comparison']
        if o=='sto':repairs.append('Author stomach RF references absent sto_data(add_reliability).csv; released concat table used. Exact historical training-set recovery is unavailable.')
        backend='sklearn CPU';scale_scope='train subset only'
    else:
        from xgboost import XGBClassifier
        ratio=.3;splitseed=[0,1,0,4][j]
        ti,vi=next(StratifiedShuffleSplit(n_splits=1,test_size=ratio,random_state=splitseed).split(fp,y))
        scaler=StandardScaler().fit(q);params=xgparams[j]
        model=XGBClassifier(objective='binary:logistic',eval_metric='auc',scale_pos_weight=float((y[ti]==0).sum()/(y[ti]==1).sum()),random_state=42,n_jobs=2,device='cuda',tree_method='hist',**params)
        repairs=['Author non-concat training files are absent; use released organ concat tables shared by other comparators','CUDA histogram backend used on this host; original backend/version not fixed in released notebook','QED scaling follows author XGB code: full training-source table before internal split']
        if o=='liv':repairs.append('Released test_size=0. is invalid; fixed to 0.3 as three other XGB final training notebooks. Exact historical liver split cannot be recovered.')
        backend='XGBoost CUDA hist';scale_scope='full training source before validation split (author behavior)'
    x=np.concatenate([fp,scaler.transform(q)],axis=1).astype(np.float32)
    xt=np.concatenate([ft,scaler.transform(qt)],axis=1).astype(np.float32)
    cfg=dict(model=name,organ=o,params=params,seed=42,split_seed=splitseed,val_ratio=ratio,train_indices=ti,validation_indices=vi,input_sha256=sha(U/f'data/single_task/{o}_data(add_reliability)_concat.csv'),feature='Morgan radius2 1024 bits + QED.properties 8 values',scale_scope=scale_scope,backend=backend,repairs=repairs)
    dump(d/'config.json',cfg)
    model.fit(x[ti],y[ti]);joblib.dump({'model':model,'scaler':scaler},d/'model.joblib')
    v=tr.iloc[vi].copy();v['prediction']=model.predict_proba(x[vi])[:,1]
    save_result(name,o,te,model.predict_proba(xt)[:,1],cfg,v)
